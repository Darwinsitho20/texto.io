
-- consulta_1.sql
SELECT XMLELEMENT("Empleados",
         XMLAGG(
            XMLELEMENT("Empleado",
              XMLFOREST(
                e.first_name AS "Nombre",
                e.last_name AS "Apellido",
                d.department_name AS "Departamento"
              )
            )
         )
       ) AS resultado_xml
FROM 
    employees e
JOIN 
    departments d ON e.department_id = d.department_id;
