-- Forzar eliminación (por si hay una tabla departments sin manager_id)
BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE employees CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/

BEGIN
    EXECUTE IMMEDIATE 'DROP TABLE departments CASCADE CONSTRAINTS';
EXCEPTION WHEN OTHERS THEN NULL;
END;
/
-- Crear tabla departments con columna manager_id
CREATE TABLE departments (
    department_id NUMBER PRIMARY KEY,
    department_name VARCHAR2(50),
    manager_id NUMBER
);

-- Crear tabla employees
CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    first_name VARCHAR2(50),
    last_name VARCHAR2(50),
    salary NUMBER,
    department_id NUMBER,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);
-- Insertar departamentos con managers definidos
INSERT INTO departments VALUES (10, 'Sales', 1);
INSERT INTO departments VALUES (20, 'Finance', 2);
INSERT INTO departments VALUES (30, 'Marketing', 3);
INSERT INTO departments VALUES (40, 'Accounting', 4);
INSERT INTO departments VALUES (50, 'Shipping', 5);

-- Insertar empleados
INSERT INTO employees VALUES (1, 'Ana', 'Gomez', 12000, 10); -- Manager
INSERT INTO employees VALUES (6, 'Luis', 'Lopez', 8300, 10);
INSERT INTO employees VALUES (2, 'Carlos', 'Martinez', 11000, 20); -- Manager
INSERT INTO employees VALUES (7, 'Marta', 'Diaz', 7200, 20);
INSERT INTO employees VALUES (3, 'Beatriz', 'Fernandez', 13000, 30); -- Manager
INSERT INTO employees VALUES (8, 'Jose', 'Perez', 9200, 30);
INSERT INTO employees VALUES (4, 'David', 'Ramirez', 12500, 40); -- Manager
INSERT INTO employees VALUES (9, 'Laura', 'Mendez', 9200, 40);
INSERT INTO employees VALUES (5, 'Ernesto', 'Suarez', 12200, 50); -- Manager
INSERT INTO employees VALUES (10, 'Andres', 'Torres', 8000, 50);

COMMIT;
WITH EmployeesWithRole AS (
    SELECT 
        e.employee_id, 
        e.salary,
        d.department_id,
        d.department_name,
        CASE 
            WHEN e.employee_id = d.manager_id THEN 'Manager'
            ELSE 'Non-Manager'
        END AS role_type
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
),
AvgSalariesByRole AS (
    SELECT 
        department_id,
        role_type,
        ROUND(AVG(salary), 2) AS avg_salary
    FROM EmployeesWithRole
    GROUP BY department_id, role_type
)
SELECT 
    d.department_name,
    ROUND(AVG(CASE WHEN a.role_type = 'Manager' THEN a.avg_salary END), 2) AS avg_manager_salary,
    ROUND(AVG(CASE WHEN a.role_type = 'Non-Manager' THEN a.avg_salary END), 2) AS avg_non_manager_salary,
    ROUND(AVG(CASE WHEN a.role_type = 'Manager' THEN a.avg_salary END) - 
          AVG(CASE WHEN a.role_type = 'Non-Manager' THEN a.avg_salary END), 2) AS avg_salary_difference
FROM AvgSalariesByRole a
JOIN departments d ON a.department_id = d.department_id
GROUP BY d.department_name
HAVING COUNT(DISTINCT a.role_type) = 2
ORDER BY d.department_name;

