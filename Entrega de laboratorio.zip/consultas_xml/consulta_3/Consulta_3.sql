WITH DepartmentSalaries AS (
    SELECT 
        d.department_name, 
        SUM(e.salary) AS department_total_salary
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    WHERE d.department_id IS NOT NULL
    GROUP BY d.department_name
),
TotalCompanySalary AS (
    SELECT SUM(salary) AS total_salary FROM employees
)
SELECT 
    ds.department_name,
    ds.department_total_salary,
    ROUND((ds.department_total_salary / tcs.total_salary) * 100, 2) AS percentage_of_total
FROM DepartmentSalaries ds, TotalCompanySalary tcs
WHERE ds.department_name IS NOT NULL
ORDER BY percentage_of_total DESC;
-- Eliminar tablas si ya existen
DROP TABLE employees CASCADE CONSTRAINTS;
DROP TABLE departments CASCADE CONSTRAINTS;

-- Crear tabla de departamentos
CREATE TABLE departments (
    department_id NUMBER PRIMARY KEY,
    department_name VARCHAR2(50)
);

-- Crear tabla de empleados
CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    employee_name VARCHAR2(50),
    salary NUMBER,
    department_id NUMBER,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);
-- Insertar departamentos
INSERT INTO departments VALUES (10, 'Sales');
INSERT INTO departments VALUES (20, 'Finance');
INSERT INTO departments VALUES (30, 'HR');
INSERT INTO departments VALUES (40, 'IT');

-- Insertar empleados
INSERT INTO employees VALUES (1, 'Alice', 5000, 10);
INSERT INTO employees VALUES (2, 'Bob', 4500, 10);
INSERT INTO employees VALUES (3, 'Charlie', 6000, 20);
INSERT INTO employees VALUES (4, 'Diana', 5500, 20);
INSERT INTO employees VALUES (5, 'Eva', 4000, 30);
INSERT INTO employees VALUES (6, 'Frank', 7000, 40);
INSERT INTO employees VALUES (7, 'Grace', 7200, 40);

COMMIT;
SELECT 
    e.employee_name,
    e.salary,
    d.department_name,
    ROUND(AVG(e.salary) OVER (PARTITION BY d.department_name), 2) AS avg_department_salary
FROM employees e
JOIN departments d ON e.department_id = d.department_id
ORDER BY d.department_name, e.employee_name;
WITH DepartmentSalaries AS (
    SELECT 
        d.department_name, 
        SUM(e.salary) AS department_total_salary
    FROM employees e
    JOIN departments d ON e.department_id = d.department_id
    GROUP BY d.department_name
),
TotalCompanySalary AS (
    SELECT SUM(salary) AS total_salary FROM employees
)
SELECT 
    ds.department_name,
    ds.department_total_salary,
    ROUND((ds.department_total_salary / tcs.total_salary) * 100, 2) AS percentage_of_total
FROM DepartmentSalaries ds, TotalCompanySalary tcs
ORDER BY percentage_of_total DESC;
