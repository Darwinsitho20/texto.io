SELECT 
    e.first_name,
    e.last_name,
    e.salary,
    d.department_name,
    ROUND(AVG(e.salary) OVER (PARTITION BY e.department_id), 0) AS avg_dept_salary
FROM 
    employees e
JOIN 
    departments d ON e.department_id = d.department_id
ORDER BY 
    d.department_name, e.salary DESC;

-- Eliminar tablas si existen
DROP TABLE employees CASCADE CONSTRAINTS;
DROP TABLE departments CASCADE CONSTRAINTS;

-- Crear tabla de departamentos
CREATE TABLE departments (
    department_id NUMBER PRIMARY KEY,
    department_name VARCHAR2(50)
);

-- Crear tabla de empleados
CREATE TABLE employees (
    employee_id NUMBER PRIMARY KEY,
    first_name VARCHAR2(50),
    last_name VARCHAR2(50),
    salary NUMBER,
    department_id NUMBER,
    FOREIGN KEY (department_id) REFERENCES departments(department_id)
);

-- Insertar datos
INSERT INTO departments VALUES (10, 'Contabilidad');
INSERT INTO departments VALUES (20, 'Tecnología');
INSERT INTO departments VALUES (30, 'Recursos Humanos');

INSERT INTO employees VALUES (1, 'Juan', 'Pérez', 4500, 10);
INSERT INTO employees VALUES (2, 'Ana', 'Rodríguez', 4200, 10);
INSERT INTO employees VALUES (3, 'Carlos', 'López', 5000, 10);
INSERT INTO employees VALUES (4, 'Luisa', 'Martínez', 3900, 20);
INSERT INTO employees VALUES (5, 'Miguel', 'Santos', 2800, 20);
INSERT INTO employees VALUES (6, 'Laura', 'Gómez', 3200, 30);
INSERT INTO employees VALUES (7, 'Diego', 'Ramírez', 3100, NULL); -- Sin departamento

COMMIT;

-- Consulta enriquecida
SELECT 
    e.first_name,
    e.last_name,
    e.salary,
    d.department_name,
    ROUND(AVG(e.salary) OVER (PARTITION BY e.department_id), 0) AS avg_dept_salary
FROM 
    employees e
JOIN 
    departments d ON e.department_id = d.department_id
ORDER BY 
    d.department_name, e.salary DESC;

